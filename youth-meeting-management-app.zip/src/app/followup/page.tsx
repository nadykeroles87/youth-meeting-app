"use client";

import { useEffect, useState } from "react";
import PageWrapper from "@/components/PageWrapper";
import Link from "next/link";
import { UserSearch, Phone, AlertTriangle, Clock, ChevronLeft, Users } from "lucide-react";

type AbsentMember = {
  id: number;
  name: string;
  phone: string | null;
  gender: string;
  familyId: number | null;
  lastAttendance: string | null;
  absentDays: number | null;
};

export default function FollowupPage() {
  const [absentMembers, setAbsentMembers] = useState<AbsentMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [weeks, setWeeks] = useState(2);

  const fetchAbsent = async () => {
    setLoading(true);
    const res = await fetch(`/api/followup?absentWeeks=${weeks}`);
    const data = await res.json();
    setAbsentMembers(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchAbsent();
  }, [weeks]);

  const urgencyColor = (days: number | null) => {
    if (!days) return "bg-red-100 text-red-700 border-red-200";
    if (days >= 30) return "bg-red-100 text-red-700 border-red-200";
    if (days >= 14) return "bg-amber-100 text-amber-700 border-amber-200";
    return "bg-yellow-100 text-yellow-700 border-yellow-200";
  };

  const urgencyLabel = (days: number | null) => {
    if (!days) return "لم يحضر قط";
    if (days >= 30) return `${days} يوم`;
    if (days >= 14) return `${days} يوم`;
    return `${days} يوم`;
  };

  return (
    <PageWrapper>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-amber-900 flex items-center gap-2">
            <UserSearch size={24} className="text-amber-600" />
            قائمة الافتقاد
          </h1>
          <p className="text-stone-500 text-sm mt-1">
            الشباب اللي محتاجين افتقاد ومتابعة
          </p>
        </div>

        {/* Filter */}
        <div className="bg-white rounded-2xl shadow-sm border border-amber-100 p-5">
          <h2 className="font-semibold text-stone-700 mb-3 text-sm">عرض الغائبين منذ أكثر من:</h2>
          <div className="flex flex-wrap gap-2">
            {[1, 2, 3, 4].map((w) => (
              <button
                key={w}
                onClick={() => setWeeks(w)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  weeks === w
                    ? "bg-amber-600 text-white shadow-md"
                    : "bg-amber-50 text-amber-700 hover:bg-amber-100"
                }`}
              >
                {w === 1 ? "أسبوع" : w === 2 ? "أسبوعان" : `${w} أسابيع`}
              </button>
            ))}
          </div>
        </div>

        {/* Stats Banner */}
        <div className="bg-gradient-to-r from-amber-700 to-amber-900 rounded-2xl p-5 text-white flex items-center gap-5">
          <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center flex-shrink-0">
            <AlertTriangle size={28} />
          </div>
          <div>
            <p className="text-amber-200 text-sm">محتاجين افتقاد</p>
            <p className="text-4xl font-bold">{absentMembers.length}</p>
            <p className="text-amber-300 text-xs mt-1">
              شاب/ة غائب/ة أكثر من {weeks === 1 ? "أسبوع" : weeks === 2 ? "أسبوعين" : `${weeks} أسابيع`}
            </p>
          </div>
        </div>

        {/* List */}
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="bg-white rounded-2xl h-20 animate-pulse" />
            ))}
          </div>
        ) : absentMembers.length === 0 ? (
          <div className="bg-white rounded-2xl p-16 text-center shadow-sm border border-amber-100">
            <Users size={60} className="mx-auto text-green-300 mb-4" />
            <h3 className="text-xl font-bold text-stone-700 mb-2">🎉 ممتاز!</h3>
            <p className="text-stone-500">
              كل الشباب حضروا خلال آخر {weeks === 1 ? "أسبوع" : weeks === 2 ? "أسبوعين" : `${weeks} أسابيع`}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {absentMembers.map((member) => (
              <div
                key={member.id}
                className="bg-white rounded-2xl shadow-sm border border-amber-100 hover:border-amber-300 transition-all overflow-hidden"
              >
                <div className="flex items-center gap-4 p-4">
                  {/* Avatar */}
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-bold flex-shrink-0 ${
                    member.gender === "female" ? "bg-pink-100 text-pink-700" : "bg-blue-100 text-blue-700"
                  }`}>
                    {member.name.slice(0, 1)}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-stone-800 text-sm">{member.name}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      {member.phone && (
                        <a
                          href={`tel:${member.phone}`}
                          className="flex items-center gap-1 text-xs text-stone-400 hover:text-amber-600 transition-colors"
                        >
                          <Phone size={11} />
                          {member.phone}
                        </a>
                      )}
                      <span className="flex items-center gap-1 text-xs text-stone-400">
                        <Clock size={11} />
                        {member.lastAttendance
                          ? `آخر حضور: ${new Date(member.lastAttendance).toLocaleDateString("ar-EG")}`
                          : "لم يحضر من قبل"}
                      </span>
                    </div>
                  </div>

                  {/* Absent Days Badge */}
                  <div className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex-shrink-0 ${urgencyColor(member.absentDays)}`}>
                    {urgencyLabel(member.absentDays)}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {member.phone && (
                      <a
                        href={`https://wa.me/2${member.phone}`}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 bg-green-50 hover:bg-green-100 text-green-600 rounded-xl transition-colors text-sm"
                        title="واتساب"
                      >
                        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
                          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                        </svg>
                      </a>
                    )}
                    <Link
                      href={`/members/${member.id}`}
                      className="flex items-center gap-1 bg-amber-50 hover:bg-amber-100 text-amber-700 px-3 py-1.5 rounded-xl text-xs font-medium transition-colors"
                    >
                      الملف
                      <ChevronLeft size={12} />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </PageWrapper>
  );
}
