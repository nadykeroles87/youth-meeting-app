import { NextResponse } from "next/server";
import { db } from "@/db";
import { families, members, meetings, servants, announcements } from "@/db/schema";
import { randomUUID } from "crypto";

export async function POST() {
  try {
    // Create families
    const [family1] = await db
      .insert(families)
      .values({ name: "أسرة القيامة", description: "أسرة الشباب الأول" })
      .returning();

    const [family2] = await db
      .insert(families)
      .values({ name: "أسرة الفادي", description: "أسرة الشباب الثاني" })
      .returning();

    const [family3] = await db
      .insert(families)
      .values({ name: "أسرة النور", description: "أسرة الشابات" })
      .returning();

    // Create servants
    await db.insert(servants).values([
      { name: "مينا سمير", phone: "01001234567", role: "admin", familyId: family1.id },
      { name: "جورج أمير", phone: "01112345678", role: "servant", familyId: family1.id },
      { name: "بيتر نبيل", phone: "01223456789", role: "servant", familyId: family2.id },
    ]);

    // Create members
    const memberData = [
      { name: "مارك أنطوان", phone: "01001111111", gender: "male" as const, college: "هندسة القاهرة", familyId: family1.id, birthDate: "2002-03-15", confessionFather: "الأنبا بيشوي" },
      { name: "كيرلس رفيق", phone: "01002222222", gender: "male" as const, college: "طب عين شمس", familyId: family1.id, birthDate: "2001-07-22", confessionFather: "الأنبا بيشوي" },
      { name: "باسيليوس مجدي", phone: "01003333333", gender: "male" as const, job: "مهندس", familyId: family2.id, birthDate: "2000-01-10" },
      { name: "فيلبس سعد", phone: "01004444444", gender: "male" as const, college: "تجارة حلوان", familyId: family2.id, birthDate: "2003-11-05" },
      { name: "بولس ماهر", phone: "01005555555", gender: "male" as const, college: "علوم الحاسب", familyId: family1.id, birthDate: "2002-08-18" },
      { name: "ماريا سامي", phone: "01006666666", gender: "female" as const, college: "تربية عين شمس", familyId: family3.id, birthDate: "2001-04-25" },
      { name: "مريم رامي", phone: "01007777777", gender: "female" as const, job: "معلمة", familyId: family3.id, birthDate: "2000-12-30" },
      { name: "ريهام طارق", phone: "01008888888", gender: "female" as const, college: "صيدلة الزقازيق", familyId: family3.id, birthDate: "2003-06-14" },
      { name: "نانسي يوسف", phone: "01009999999", gender: "female" as const, college: "آداب عين شمس", familyId: family3.id, birthDate: "2002-09-02" },
      { name: "إيريس هاني", phone: "01010101010", gender: "female" as const, job: "مهندسة", familyId: family3.id, birthDate: "2001-02-17" },
    ];

    const insertedMembers = await Promise.all(
      memberData.map((m) =>
        db
          .insert(members)
          .values({ ...m, qrCode: `MNK-${randomUUID().slice(0, 8).toUpperCase()}` })
          .returning()
      )
    );

    // Create meetings
    const [meeting1] = await db
      .insert(meetings)
      .values({
        title: "اجتماع الأحد الأول",
        topic: "أنا هو القيامة والحياة",
        speaker: "الأنبا بيشوي",
        meetingDate: "2025-01-05",
      })
      .returning();

    const [meeting2] = await db
      .insert(meetings)
      .values({
        title: "اجتماع الأحد الثاني",
        topic: "منقوش على كفيّ",
        speaker: "القس بولس ميخائيل",
        meetingDate: "2025-01-12",
      })
      .returning();

    const [meeting3] = await db
      .insert(meetings)
      .values({
        title: "اجتماع الأحد الثالث",
        topic: "الله محبة",
        speaker: "القس بطرس سامي",
        meetingDate: "2025-01-19",
      })
      .returning();

    // Add announcements
    await db.insert(announcements).values([
      {
        title: "رحلة الصيف 2025 🌊",
        content: "هيتم تسجيل أسماء الراغبين في رحلة الصيف من يوم الأحد القادم. الرحلة هتكون يوم 15 فبراير. التسجيل مفتوح للجميع!",
        isPinned: true,
      },
      {
        title: "مؤتمر الشباب 2025 🙏",
        content: "مؤتمر الشباب القبطي هيبدأ من 20 يناير. اتواصلوا مع الخدام لتسجيل أسماءكم وحجز أماكنكم.",
        isPinned: false,
      },
      {
        title: "تغيير موعد الاجتماع ⏰",
        content: "تنبيه: اجتماع الأسبوع القادم هيكون الساعة 6 مساءً بدلاً من 5 مساءً. ربنا يبارككم.",
        isPinned: false,
      },
    ]);

    return NextResponse.json({ success: true, message: "تم إضافة البيانات التجريبية بنجاح" });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to seed data" }, { status: 500 });
  }
}
