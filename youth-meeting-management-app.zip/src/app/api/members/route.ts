import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { members, families } from "@/db/schema";
import { eq, ilike, or, desc } from "drizzle-orm";
import { randomUUID } from "crypto";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search");
    const familyId = searchParams.get("familyId");
    const status = searchParams.get("status");

    let query = db
      .select({
        id: members.id,
        name: members.name,
        phone: members.phone,
        birthDate: members.birthDate,
        gender: members.gender,
        college: members.college,
        job: members.job,
        address: members.address,
        confessionFather: members.confessionFather,
        familyId: members.familyId,
        qrCode: members.qrCode,
        status: members.status,
        notes: members.notes,
        createdAt: members.createdAt,
        familyName: families.name,
      })
      .from(members)
      .leftJoin(families, eq(members.familyId, families.id))
      .orderBy(desc(members.createdAt));

    const results = await query;

    let filtered = results;

    if (search) {
      const s = search.toLowerCase();
      filtered = filtered.filter(
        (m) =>
          m.name.toLowerCase().includes(s) ||
          (m.phone && m.phone.includes(s))
      );
    }

    if (familyId) {
      filtered = filtered.filter((m) => m.familyId === parseInt(familyId));
    }

    if (status) {
      filtered = filtered.filter((m) => m.status === status);
    }

    return NextResponse.json(filtered);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch members" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const qrCode = `MNK-${randomUUID().slice(0, 8).toUpperCase()}`;

    const [member] = await db
      .insert(members)
      .values({
        name: body.name,
        phone: body.phone || null,
        birthDate: body.birthDate || null,
        gender: body.gender || "male",
        college: body.college || null,
        job: body.job || null,
        address: body.address || null,
        confessionFather: body.confessionFather || null,
        familyId: body.familyId ? parseInt(body.familyId) : null,
        qrCode,
        status: body.status || "active",
        notes: body.notes || null,
      })
      .returning();

    return NextResponse.json(member, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create member" }, { status: 500 });
  }
}
