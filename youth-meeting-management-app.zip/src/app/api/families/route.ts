import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { families, members, servants } from "@/db/schema";
import { eq, count } from "drizzle-orm";

export async function GET() {
  try {
    const allFamilies = await db.select().from(families).orderBy(families.name);

    const familiesWithCount = await Promise.all(
      allFamilies.map(async (family) => {
        const [{ value }] = await db
          .select({ value: count() })
          .from(members)
          .where(eq(members.familyId, family.id));
        return { ...family, memberCount: Number(value) };
      })
    );

    return NextResponse.json(familiesWithCount);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch families" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [family] = await db
      .insert(families)
      .values({
        name: body.name,
        description: body.description || null,
      })
      .returning();

    return NextResponse.json(family, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create family" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    await db.delete(families).where(eq(families.id, parseInt(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to delete family" }, { status: 500 });
  }
}
