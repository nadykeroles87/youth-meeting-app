"use client";

import { useEffect, useState } from "react";
import PageWrapper from "@/components/PageWrapper";
import { Church, Plus, Users, Trash2, X } from "lucide-react";

type Family = {
  id: number;
  name: string;
  description: string | null;
  memberCount: number;
};

export default function FamiliesPage() {
  const [families, setFamilies] = useState<Family[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", description: "" });
  const [saving, setSaving] = useState(false);

  const fetchFamilies = async () => {
    const res = await fetch("/api/families");
    setFamilies(await res.json());
    setLoading(false);
  };

  useEffect(() => { fetchFamilies(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await fetch("/api/families", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
    setForm({ name: "", description: "" });
    setShowForm(false);
    fetchFamilies();
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`هل تريد حذف أسرة "${name}"؟`)) return;
    await fetch(`/api/families?id=${id}`, { method: "DELETE" });
    fetchFamilies();
  };

  const familyColors = [
    "from-amber-500 to-amber-700",
    "from-orange-500 to-orange-700",
    "from-yellow-500 to-yellow-700",
    "from-red-500 to-red-700",
    "from-rose-500 to-rose-700",
  ];

  return (
    <PageWrapper>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-amber-900 flex items-center gap-2">
              <Church size={24} className="text-amber-600" />
              الأسر
            </h1>
            <p className="text-stone-500 text-sm mt-1">{families.length} أسرة</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-4 py-2.5 rounded-xl font-medium text-sm transition-colors shadow-md"
          >
            <Plus size={16} />
            أسرة جديدة
          </button>
        </div>

        {/* Add Family Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-lg font-bold text-stone-800">أسرة جديدة</h2>
                <button onClick={() => setShowForm(false)}>
                  <X size={20} className="text-stone-400" />
                </button>
              </div>
              <form onSubmit={handleCreate} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-stone-700 mb-1.5">
                    اسم الأسرة <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="مثال: أسرة القيامة"
                    className="w-full border border-amber-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-stone-700 mb-1.5">وصف</label>
                  <input
                    type="text"
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="وصف مختصر"
                    className="w-full border border-amber-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                  />
                </div>
                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 border border-amber-200 text-stone-600 py-2.5 rounded-xl text-sm font-medium"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="flex-1 bg-amber-600 text-white py-2.5 rounded-xl text-sm font-medium disabled:bg-amber-300"
                  >
                    {saving ? "جاري..." : "إنشاء"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-36 bg-white rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : families.length === 0 ? (
          <div className="bg-white rounded-2xl p-16 text-center shadow-sm border border-amber-100">
            <Church size={60} className="mx-auto text-amber-200 mb-4" />
            <h3 className="text-xl font-bold text-stone-700 mb-2">لا توجد أسر</h3>
            <p className="text-stone-400 mb-6">ابدأ بإنشاء أول أسرة</p>
            <button
              onClick={() => setShowForm(true)}
              className="inline-flex items-center gap-2 bg-amber-600 text-white px-6 py-2.5 rounded-xl text-sm font-medium"
            >
              <Plus size={16} />
              إنشاء أسرة
            </button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {families.map((family, index) => (
              <div
                key={family.id}
                className="bg-white rounded-2xl shadow-sm border border-amber-100 overflow-hidden card-hover"
              >
                <div className={`bg-gradient-to-r ${familyColors[index % familyColors.length]} p-5 text-white`}>
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                      <Church size={24} />
                    </div>
                    <button
                      onClick={() => handleDelete(family.id, family.name)}
                      className="p-1.5 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <h3 className="font-bold text-lg mt-3">{family.name}</h3>
                  {family.description && (
                    <p className="text-white/70 text-sm mt-0.5">{family.description}</p>
                  )}
                </div>
                <div className="p-4 flex items-center gap-2">
                  <Users size={16} className="text-amber-500" />
                  <span className="text-stone-600 text-sm font-medium">{family.memberCount} عضو</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </PageWrapper>
  );
}
