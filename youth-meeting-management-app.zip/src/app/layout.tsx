import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "منقوش على كفك - اجتماع الشباب",
  description: "تطبيق اجتماع شباب كنيسة العذراء - العاشر من رمضان",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-amber-50 text-stone-900 antialiased">{children}</body>
    </html>
  );
}
