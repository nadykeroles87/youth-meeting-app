"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Users,
  CalendarDays,
  CheckSquare,
  Home,
  Heart,
  Bell,
  UserSearch,
  ChevronRight,
  Church,
  X,
  Menu,
} from "lucide-react";
import { useState } from "react";

const navItems = [
  { href: "/", label: "الرئيسية", icon: Home },
  { href: "/meetings", label: "الاجتماعات", icon: CalendarDays },
  { href: "/attendance", label: "تسجيل الحضور", icon: CheckSquare },
  { href: "/members", label: "قاعدة الشباب", icon: Users },
  { href: "/families", label: "الأسر", icon: Church },
  { href: "/followup", label: "الافتقاد", icon: UserSearch },
  { href: "/prayers", label: "طلبات الصلاة", icon: Heart },
  { href: "/announcements", label: "الإعلانات", icon: Bell },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-5 border-b border-amber-700/30">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center text-2xl font-bold text-amber-800 border-2 border-amber-600 shadow-md">
            ✋
          </div>
          <div>
            <h1 className="text-white font-bold text-sm leading-tight">منقوش على كفك</h1>
            <p className="text-amber-300 text-xs">كنيسة العذراء - العاشر من رمضان</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                active
                  ? "bg-amber-500 text-white shadow-lg shadow-amber-500/30"
                  : "text-amber-200 hover:bg-amber-800/50 hover:text-white"
              }`}
            >
              <Icon size={18} className={active ? "text-white" : "text-amber-400 group-hover:text-amber-200"} />
              <span className="text-sm font-medium">{item.label}</span>
              {active && <ChevronRight size={14} className="mr-auto opacity-70 rotate-180" />}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-amber-700/30">
        <p className="text-amber-400 text-xs text-center">
          🙏 ربنا يبارك خدمتكم
        </p>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setMobileOpen(true)}
        className="lg:hidden fixed top-4 right-4 z-50 w-10 h-10 bg-amber-800 text-white rounded-xl flex items-center justify-center shadow-lg"
      >
        <Menu size={20} />
      </button>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile Sidebar */}
      <div
        className={`lg:hidden fixed top-0 right-0 h-full w-72 z-50 transition-transform duration-300 ${
          mobileOpen ? "translate-x-0" : "translate-x-full"
        }`}
        style={{ background: "linear-gradient(180deg, #3d2200 0%, #2d1a00 100%)" }}
      >
        <button
          onClick={() => setMobileOpen(false)}
          className="absolute top-4 left-4 text-amber-300 hover:text-white"
        >
          <X size={24} />
        </button>
        <SidebarContent />
      </div>

      {/* Desktop Sidebar */}
      <aside
        className="hidden lg:flex flex-col w-64 min-h-screen fixed right-0 top-0 z-30"
        style={{ background: "linear-gradient(180deg, #3d2200 0%, #2d1a00 100%)" }}
      >
        <SidebarContent />
      </aside>
    </>
  );
}
