"use client";

export default function SeedButton() {
  const handleSeed = async () => {
    await fetch("/api/seed", { method: "POST" });
    window.location.reload();
  };

  return (
    <button
      onClick={handleSeed}
      className="inline-flex items-center gap-2 bg-stone-600 hover:bg-stone-700 text-white px-4 py-2 rounded-xl font-medium text-sm transition-colors"
    >
      إضافة بيانات تجريبية
    </button>
  );
}
